
package com.girish.service;

import com.girish.event.PublicEvent;
import com.girish.modal.Model_User_Account;
import io.socket.client.Socket;
import io.socket.client.IO;
import io.socket.emitter.Emitter;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextArea;


public class Service {
  
    private static Service instance;
    private  Socket client;
    private final int PORT_NUMBER = 8081;
    private final String IP = "localhost";
    private Model_User_Account user;

   
  
    public static Service getInstance() {
     if(instance == null)
     {
      instance = new Service();
     }
        return instance;
    }
    
    public void startServer()
    {
      
        try {
            client = IO.socket("http://"+IP+":"+PORT_NUMBER);
            client.on("list_user", new Emitter.Listener() {
                @Override
                public void call(Object... os) {
                   // list
                   List<Model_User_Account> users = new ArrayList<>();
                   for(Object o:os)
                   {
                       users.add(new Model_User_Account(o));
                   }
                   PublicEvent.getInstance().getEventMenuleft().newUser(users);
                }
            });
            client.open();
        } catch (URISyntaxException ex) {
            System.out.println("ERROR :"+ex);
        }
        
      
    }
   public Model_User_Account getUser() {
        return user;
    }

    public void setUser(Model_User_Account user) {
        this.user = user;
    }
    public Service() 
    {
      
    }

    public Socket getClient() {
        return client;
    }
    
}
