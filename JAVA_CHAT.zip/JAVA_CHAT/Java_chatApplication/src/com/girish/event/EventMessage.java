
package com.girish.event;

import com.girish.modal.Model_Message;

public interface EventMessage {

    public void callMessage(Model_Message message);
}
