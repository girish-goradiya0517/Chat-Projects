
package com.girish.event;


public interface EventMain {
    
    public void showLoading(boolean show);
    
    public void initChat();
}
