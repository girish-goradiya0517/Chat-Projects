import java.sql.*;
public class test {
    static Connection con;
    public static void main(String[] args) {
        String Url = "jdbc:mysql://localhost:3308/chat_application";
        String user = "root";
        String password = "";
        try
        {
          Class.forName("com.mysql.jdbc.Driver");
           con = DriverManager.getConnection(Url, user, password);
            System.out.println("Connection DONE");
            PreparedStatement p = con.prepareStatement("INSERT INTO `user` (`UserID`, `UserName`, `Password`) VALUES (NULL, ?, ?);");
            p.setString(1, "yuvi");
            p.setString(2, "1233");
            p.execute();
            System.out.println("Insert Success");
            p.close();
            con.close();
            
        }
        catch(Exception e)
        {
        
        }
    }
}
