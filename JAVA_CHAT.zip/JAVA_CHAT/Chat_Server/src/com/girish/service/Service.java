
package com.girish.service;

import com.corundumstudio.socketio.AckRequest;
import com.corundumstudio.socketio.Configuration;
import com.corundumstudio.socketio.SocketIOClient;
import com.corundumstudio.socketio.SocketIOServer;
import com.corundumstudio.socketio.listener.ConnectListener;
import com.corundumstudio.socketio.listener.DataListener;
import com.girish.model.Model_Message;
import com.girish.model.Model_Login;
import com.girish.model.Model_Register;
import com.girish.model.Model_User_Account;
import java.util.List;
import javax.swing.JTextArea;


public class Service {
   
    private static Service instance;
    private  SocketIOServer server;
    private JTextArea textArea;
    private ServiceUser serviceUser;
    private final int PORT_NUMBER = 8081;
    public static Service getInstance( JTextArea textArea) {
     if(instance == null)
     {
      instance = new Service(textArea);
     }
        return instance;
    }
     public Service( JTextArea textArea) 
    {
        this.textArea = textArea;
        serviceUser = new ServiceUser();
    }
    public void startServer()
    {
        Configuration config = new Configuration();
        config.setPort(PORT_NUMBER);
        server = new SocketIOServer(config);
        server.addConnectListener(new ConnectListener() {
            @Override
            public void onConnect(SocketIOClient client) {
               textArea.append("One Client Connected\n");
            }
        });
         server.addEventListener("register", Model_Register.class, new DataListener<Model_Register>() {
            @Override
            public void onData(SocketIOClient sioc, Model_Register t, AckRequest ar) throws Exception {
                Model_Message message = serviceUser.register(t);
                ar.sendAckData(message.isAction(), message.getMessage(),message.getData());
                if(message.isAction())
                {textArea.append("User has Register :" + t.getUserName() + "| Pass :" + t.getPassword() + "\n");
                    server.getBroadcastOperations().sendEvent("list_user", (Model_User_Account) message.getData());
                }
            }
        });
         server.addEventListener("login",Model_Login.class , new DataListener<Model_Login>() {
            @Override
            public void onData(SocketIOClient cl, Model_Login t, AckRequest ar) throws Exception {
            Model_User_Account login  = serviceUser.login(t);
             if(login != null){
             ar.sendAckData(true,login);
             }
             else
             {
             ar.sendAckData(false);
             }
            }
         }
         );
         server.addEventListener("list_user", Integer.class, new DataListener<Integer>() {
            @Override
            public void onData(SocketIOClient cleint, Integer UserID, AckRequest arg2) throws Exception {
                try {
                    
                    List<Model_User_Account> list = serviceUser.getUser(UserID);
                    cleint.sendEvent("list_user", list.toArray());
                } 
                catch (Exception e)
                {
                }
            }
         });
        server.start();
        textArea.append("Server Has Started on this Port :"+PORT_NUMBER+ "\n");
    }

   
    
}
