
package com.girish.connection;
import java.sql.*;

public class DatabaseConnectoion
{
    private static DatabaseConnectoion instance;
    private Connection connection;

    public void setConnection(Connection connection) {
        this.connection = connection;
    }
    public static DatabaseConnectoion getInstance() {
       if(instance == null)
       {
        instance = new DatabaseConnectoion();
       }
        return instance;
    }

    private DatabaseConnectoion() {
    }
    public void connectToDatabase() throws SQLException
    {
        String Url = "jdbc:mysql://localhost:3308/chat_application";
        String user = "root";
        String password = "";
        try
        {
          Class.forName("com.mysql.jdbc.Driver");
           connection = DriverManager.getConnection(Url, user, password);
        }
        catch(Exception e)
        {
        
        }
    }
        public Connection getConnection() {
        return connection;
    }
}
